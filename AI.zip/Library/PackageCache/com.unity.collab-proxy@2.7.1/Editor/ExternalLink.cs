namespace Unity.PlasticSCM.Editor
{
    internal struct ExternalLink
    {
        internal string Label;
        internal string Url;
    }
}
